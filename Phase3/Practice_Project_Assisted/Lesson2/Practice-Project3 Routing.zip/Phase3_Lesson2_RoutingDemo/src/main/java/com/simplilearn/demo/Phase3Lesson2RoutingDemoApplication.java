package com.simplilearn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class Phase3Lesson2RoutingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase3Lesson2RoutingDemoApplication.class, args);
	}

}

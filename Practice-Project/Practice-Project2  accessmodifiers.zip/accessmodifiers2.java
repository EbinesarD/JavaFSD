package lesson1;

public class accessmodifiers2 extends accessmodifiers1
{
	public static void main(String[] args)
	{
		accessmodifiers2 ac = new accessmodifiers2();
		ac.pro_func();
		ac.pub_func();
	}

}
